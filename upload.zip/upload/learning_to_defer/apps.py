from django.apps import AppConfig


class LearningToDeferConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "learning_to_defer"
